# Kamus
- Halaman untuk pencarian kata English-Indonesia dan Indonesia-English.
- Proses load data hanya dilakukan saat pertama kali aplikasi dijalankan.
- Menggunakan data kamus yang bersumber dari berkas berbentuk text.
